#!/usr/bin/env python

if __name__ == "__main__":
	import palinagent.daemon.main
	palinagent.daemon.main.main_func()
