ProActive Agent is a system daemon to automatically starts ProActive runtimes according to a weekly schedule

