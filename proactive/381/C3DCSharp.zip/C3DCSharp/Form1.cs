
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.Runtime.Remoting.Channels.Tcp;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting;
using C3DClient;
using Test_Remoting.proactive;

namespace C3DClient
{
	[Serializable]
	public class Form1 : System.Windows.Forms.Form
	{
		/// Variable n�cessaire au concepteur.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private Bitmap b;

		private RemotingServer server;
		private RemoteObj remoteObj;
		private string userName;
		private string url;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.TextBox infos;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button sRightButton;
		private System.Windows.Forms.Button sLeftButton;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button rightButton;
		private System.Windows.Forms.Button upButton;
		private System.Windows.Forms.Button downButton;
		private System.Windows.Forms.Button leftButton;
		private System.Windows.Forms.PictureBox pic;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.ProgressBar pb;
		private LoginForm loginForm;
		private System.Windows.Forms.MenuItem menuItem3;

		private C3DDispatcher dispatcher;
		
		private int userId;
		
		public Form1(string name, string url, LoginForm loginForm) 
		{
			//
			// Requis pour la prise en charge du Concepteur Windows Forms
			//
			InitializeComponent();
			this.loginForm = loginForm;
			this.userName = name;
			this.server = new RemotingServer (userName);
			//Console.WriteLine("name = " + name);
			this.userName = name;
			this.url = url;
			
			this.dispatcher = new C3DDispatcher (url);
			
			this.remoteObj = (RemoteObj)Activator.GetObject(typeof(RemoteObj),
				"tcp://localhost:1234/" + userName);
			
			surveiller();

			registerMe ();
			//Affichage de la scene 3d
			b = new Bitmap(270,270);
			pic.Image = b;
			pb.Maximum = 100;
			label2.Text = name;
			label3.Text = url;

			//this.refreshPicture();
			showMessage("C3D web service client is ready");
			
		}
 
		private void registerMe () 
		{
			string MyUrl = "http://" + System.Net.Dns.GetHostName () + "/TestWS/Service1.asmx"  ;
			//Console.WriteLine(url);
			this.userId = this.dispatcher.registerWSUser(this.userName, MyUrl);
		}

		private void surveiller () 
		{
			this.remoteObj.AccessMyEvent += new EventHandler(gestionObj);
			//this.remoteObj.AccessUser += new EventHandler(gestionUsers);
			this.remoteObj.AccessMessage += new EventHandler(gestionMessages);
		}

		public void gestionMessages (Object sender, EventArgs e) 
		{
			string message = ((C3DClient.C3DEventMessage)e).getMessage();
			//chatBox.AppendText(message.Trim() + System.Environment.NewLine);
		}

		public void gestionUsers(Object sender, EventArgs e) 
		{
			User user = ((C3DClient.C3DEventUser)e).getUser();
			bool left = ((C3DClient.C3DEventUser)e).isUserLeft();
			
			
		}

		public void gestionObj (Object sender, EventArgs e) 
		{
			Object o = ((C3DClient.C3DEventArgs)e).getLastArg();
			if (o.GetType() ==  typeof(string))
				showMessage((string)o);
			else
				refreshPicture((int []) o, ((C3DClient.C3DEventArgs)e).getNumber (),((C3DClient.C3DEventArgs)e).getNbInt() );
		}
		
		

		public void setPixel (int [] pix) 
		{
		
			int y=0;
			int x=0;
			for (int i=0;y<270 ;i++)
			{
				x = i%270;
					
				b.SetPixel(x,y,System.Drawing.Color.FromArgb(pix[i]));
				b.SetPixel(x+1,y,System.Drawing.Color.FromArgb(pix[i]));
				if (i%270 == 0) 
					y++;
			
				
			}
			pb.Value = 100;
			this.Refresh();
			
			
			Application.DoEvents();
		}

		// <summary>
		/// Nettoyage des ressources utilis�es.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					
					components.Dispose();
				}
				
			}
			this.dispatcher.unregisterWSUser(this.userName, this.url);
			base.Dispose( disposing );
			loginForm.Dispose ();
		}

		#region Code g�n�r� par le Concepteur Windows Form
		/// <summary>
		/// M�thode requise pour la prise en charge du concepteur - ne modifiez pas
		/// le contenu de cette m�thode avec l'�diteur de code.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.infos = new System.Windows.Forms.TextBox();
			this.button4 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.sRightButton = new System.Windows.Forms.Button();
			this.sLeftButton = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.rightButton = new System.Windows.Forms.Button();
			this.upButton = new System.Windows.Forms.Button();
			this.downButton = new System.Windows.Forms.Button();
			this.leftButton = new System.Windows.Forms.Button();
			this.pic = new System.Windows.Forms.PictureBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.pb = new System.Windows.Forms.ProgressBar();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem3});
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 0;
			this.menuItem3.Text = "";
			// 
			// infos
			// 
			this.infos.AcceptsReturn = true;
			this.infos.AcceptsTab = true;
			this.infos.AutoSize = false;
			this.infos.Enabled = false;
			this.infos.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.infos.Location = new System.Drawing.Point(440, 184);
			this.infos.Multiline = true;
			this.infos.Name = "infos";
			this.infos.ReadOnly = true;
			this.infos.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.infos.Size = new System.Drawing.Size(496, 200);
			this.infos.TabIndex = 14;
			this.infos.Text = "";
			// 
			// button4
			// 
			this.button4.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button4.Location = new System.Drawing.Point(720, 448);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(152, 56);
			this.button4.TabIndex = 13;
			this.button4.Text = "Reset";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// button3
			// 
			this.button3.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button3.Location = new System.Drawing.Point(456, 448);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(176, 56);
			this.button3.TabIndex = 12;
			this.button3.Text = "Add Random Sphere";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// sRightButton
			// 
			this.sRightButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.sRightButton.Location = new System.Drawing.Point(280, 448);
			this.sRightButton.Name = "sRightButton";
			this.sRightButton.Size = new System.Drawing.Size(120, 40);
			this.sRightButton.TabIndex = 11;
			this.sRightButton.Text = "Spin Right";
			this.sRightButton.Click += new System.EventHandler(this.sRightButton_Click);
			// 
			// sLeftButton
			// 
			this.sLeftButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.sLeftButton.Location = new System.Drawing.Point(48, 448);
			this.sLeftButton.Name = "sLeftButton";
			this.sLeftButton.Size = new System.Drawing.Size(112, 40);
			this.sLeftButton.TabIndex = 10;
			this.sLeftButton.Text = "Spin Left";
			this.sLeftButton.Click += new System.EventHandler(this.sLeftButton_Click);
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(440, 112);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(496, 40);
			this.label3.TabIndex = 9;
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label2.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(520, 40);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(416, 40);
			this.label2.TabIndex = 8;
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label1.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.label1.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(240, 40);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(240, 40);
			this.label1.TabIndex = 7;
			this.label1.Text = "User";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// rightButton
			// 
			this.rightButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rightButton.Location = new System.Drawing.Point(280, 496);
			this.rightButton.Name = "rightButton";
			this.rightButton.Size = new System.Drawing.Size(120, 40);
			this.rightButton.TabIndex = 6;
			this.rightButton.Text = "Right";
			this.rightButton.Click += new System.EventHandler(this.right);
			// 
			// upButton
			// 
			this.upButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.upButton.Location = new System.Drawing.Point(168, 448);
			this.upButton.Name = "upButton";
			this.upButton.Size = new System.Drawing.Size(104, 40);
			this.upButton.TabIndex = 0;
			this.upButton.Text = "Up";
			this.upButton.Click += new System.EventHandler(this.up);
			// 
			// downButton
			// 
			this.downButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.downButton.Location = new System.Drawing.Point(168, 544);
			this.downButton.Name = "downButton";
			this.downButton.Size = new System.Drawing.Size(104, 40);
			this.downButton.TabIndex = 2;
			this.downButton.Text = "Down";
			this.downButton.Click += new System.EventHandler(this.down);
			// 
			// leftButton
			// 
			this.leftButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.leftButton.Location = new System.Drawing.Point(48, 496);
			this.leftButton.Name = "leftButton";
			this.leftButton.Size = new System.Drawing.Size(112, 40);
			this.leftButton.TabIndex = 1;
			this.leftButton.Text = "Left";
			this.leftButton.Click += new System.EventHandler(this.left);
			// 
			// pic
			// 
			this.pic.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.pic.Location = new System.Drawing.Point(80, 112);
			this.pic.Name = "pic";
			this.pic.Size = new System.Drawing.Size(320, 288);
			this.pic.TabIndex = 4;
			this.pic.TabStop = false;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.button4);
			this.groupBox1.Controls.Add(this.button3);
			this.groupBox1.Controls.Add(this.sRightButton);
			this.groupBox1.Controls.Add(this.sLeftButton);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.rightButton);
			this.groupBox1.Controls.Add(this.upButton);
			this.groupBox1.Controls.Add(this.downButton);
			this.groupBox1.Controls.Add(this.leftButton);
			this.groupBox1.Controls.Add(this.pic);
			this.groupBox1.Controls.Add(this.pb);
			this.groupBox1.Controls.Add(this.infos);
			this.groupBox1.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox1.Location = new System.Drawing.Point(48, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(968, 600);
			this.groupBox1.TabIndex = 6;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "C3DUser";
			// 
			// pb
			// 
			this.pb.Location = new System.Drawing.Point(440, 408);
			this.pb.Name = "pb";
			this.pb.Size = new System.Drawing.Size(488, 16);
			this.pb.TabIndex = 7;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(1080, 637);
			this.Controls.Add(this.groupBox1);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Form1";
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		

		private void up(object sender, System.EventArgs e)
		{
			pb.Value=5;
			showMessage("Up operation in progress, please wait ...");
		
			dispatcher.rotateUp (this.userId);
			pb.Value = 50;
			//refreshPicture ();
			showMessage("C3D web service client is ready");
			pb.Value = 0;
		}

		private void right(object sender, System.EventArgs e)
		{
			pb.Value = 5;
			showMessage("Right operation in progress, please wait ...");
			
			this.dispatcher.rotateRight (this.userId);
			pb.Value = 50;
			//refreshPicture ();
			showMessage("C3D web service client  is ready");
			pb.Value = 0;
		}

		private void down(object sender, System.EventArgs e)
		{
			pb.Value = 5;
			showMessage("Down operation in progress, please wait ...");
			
			this.dispatcher.rotateDown (this.userId);
			pb.Value = 50;
			//refreshPicture ();
			showMessage("C3D web service client is ready");
			pb.Value =0;
		}

		private void left(object sender, System.EventArgs e)
		{
			pb.Value = 5;
			showMessage("Left operation in progress, please wait ...");	
			
			this.dispatcher.rotateLeft(this.userId);
			pb.Value = 50;
			//refreshPicture ();
			showMessage("C3D web service client is ready");
			pb.Value = 0;
		}

		private void refreshPicture(object sender, System.EventArgs e)
		{
			pb.Value = 5;
			showMessage("Refresh operation in progress, please wait ...");
			//refreshPicture();
			showMessage("C3D web service client is ready");
		}

		private void refreshPicture (int [] pix, int number, int nbInt) 
		{
							
		
			leftButton.Enabled = false;
			rightButton.Enabled = false;
			upButton.Enabled = false;
			downButton.Enabled = false;
			sLeftButton.Enabled = false;
			sRightButton.Enabled = false;

			int y=0;
			int x=0;
			for (int i=0;i<pix.Length;i++)
			{
				

				x = i%270;
				
				int y_ = y + (270/nbInt)*number;
				b.SetPixel(x,y_,System.Drawing.Color.FromArgb(pix[i]));

				
				if (i % 270  == 0)
					y++;
				

				
			}
			pb.Value = 100;
			this.Refresh();
		
			Application.DoEvents();
			leftButton.Enabled = true;
			rightButton.Enabled = true;
			upButton.Enabled = true;
			downButton.Enabled = true;
			sLeftButton.Enabled = true;
			sRightButton.Enabled = true;
			pb.Value = 0;
		}


		private void showMessage (string message) 
		{
			infos.AppendText(message.Substring(0,message.Length -1) + System.Environment.NewLine);
			
		
		}

		private void sLeftButton_Click(object sender, System.EventArgs e)
		{
			this.dispatcher.spinUnclock(this.userId);
		}

		private void sRightButton_Click(object sender, System.EventArgs e)
		{
			this.dispatcher.spinClock(this.userId);
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			this.dispatcher.addRandomSphere();
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			this.dispatcher.resetSceneWS();
		
		}

		

	
		
		

	}
}