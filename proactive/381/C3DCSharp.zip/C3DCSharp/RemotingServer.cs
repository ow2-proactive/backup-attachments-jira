using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

namespace C3DClient
{
	public class RemotingServer
	{
	
		private string userName = "titi";

		public RemotingServer(string userName)
		{
			this.userName = userName;
 
			RemotingConfiguration.RegisterWellKnownServiceType(
   
				typeof(RemoteObj),
   
				this.userName,
   
				WellKnownObjectMode.Singleton);
		
			RemotingConfiguration.Configure("Test Remoting.exe.config");
		}	

		

	}
}