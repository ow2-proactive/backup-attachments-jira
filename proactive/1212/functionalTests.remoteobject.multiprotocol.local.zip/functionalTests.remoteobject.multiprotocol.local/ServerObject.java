package functionalTests.remoteobject.multiprotocol.local;

import java.net.URI;

import org.objectweb.proactive.api.PAActiveObject;
import org.objectweb.proactive.api.PARemoteObject;
import org.objectweb.proactive.core.ProActiveException;
import org.objectweb.proactive.core.body.AbstractBody;
import org.objectweb.proactive.core.body.UniversalBody;
import org.objectweb.proactive.core.remoteobject.RemoteObjectExposer;
import org.objectweb.proactive.core.remoteobject.RemoteObjectHelper;
import org.objectweb.proactive.core.remoteobject.exception.UnknownProtocolException;

import functionalTests.activeobject.creation.A;


public class ServerObject extends A{
	
	public ServerObject(){
		
	}
	
	public ServerObject(String name){
		super(name);
	}
	
	public String doEchoRequest(String string) {
		return string;
	}

	
	public void unexport(URI uri) {
	
		
		AbstractBody myBody = (AbstractBody) PAActiveObject.getBodyOnThis();
		
		RemoteObjectExposer<UniversalBody> roe = ((AbstractBody) myBody).getRemoteObjectExposer();		
	
		try {	
			System.out.println("trying to remove " + uri.toString());
			roe.unexport(uri);
			PARemoteObject.unregister(uri);
		} catch (ProActiveException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	
	public void addProtocol(String protocol) throws UnknownProtocolException, ProActiveException{
		
		System.out.println("trying to add protocol " + protocol.toUpperCase() + " for " + this.getName() );

		AbstractBody myBody = (AbstractBody) PAActiveObject.getBodyOnThis();
		
		
		RemoteObjectExposer<UniversalBody> roe = ((AbstractBody) myBody).getRemoteObjectExposer();
		
		PARemoteObject.bind(roe,RemoteObjectHelper.generateUrl(protocol, this.getName()));
		
//		System.out.println(">>>>>" + myBody.registerByName(this.name, false, protocol));
		
		
	}
	
	
}
