package functionalTests.remoteobject.multiprotocol.local;

import static junit.framework.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;

import org.objectweb.proactive.api.PAActiveObject;
import org.objectweb.proactive.core.ProActiveException;
import org.objectweb.proactive.core.config.ProActiveConfiguration;
import org.objectweb.proactive.core.remoteobject.RemoteObjectHelper;
import org.objectweb.proactive.core.remoteobject.RemoteObjectProtocolFactoryRegistry;
import org.objectweb.proactive.core.remoteobject.RemoteObjectSet.NotYetExposedException;
import org.objectweb.proactive.core.remoteobject.exception.UnknownProtocolException;


public class InvalidFutureUsage {

    // Test Components and related attributes
 	ServerObject so;
 	ServerObject soStub;
 	String name;
 	String uriString;
 	String defaultProtocol;
 	
 	// Auxiliary Test data structures
 	public ArrayList<String> allPossibleLocalFactoriesProtocols = null; 
 	public ArrayList<String> actualEnabledLocalJVMProtocols = null;
 	public ArrayList<String> enabledServerObjectProtocols = null; 
 	public ArrayList<String> workableServerObjectProtocols = null; 
 	public ArrayList<String> orderedProtocols = null;
 	
	public InvalidFutureUsage() throws UnknownProtocolException, ProActiveException, IOException {

		inizializeTestComponents();
		
		allPossibleLocalFactoriesProtocols = getAllPossibleLocalFactoriesProtocols(); //collected by active factories exploration
		actualEnabledLocalJVMProtocols = getActualEnabledLocalJvmProtocols();  //collected by ProActiveConfiguration settings
		enabledServerObjectProtocols = actualEnabledLocalJVMProtocols; //set up, by choice, as local JVM procotols
		workableServerObjectProtocols = getActualEnabledServerObjectprotocols(); //collected by pinging Server Object with active factories protocols
		orderedProtocols = getOrderedProtocols();
	}

	@org.junit.Test
	public void executeAlgorithm() throws Exception {
		// enable Server Active Object to communicate with the same local JVM protocols
				Iterator<String> iterator = actualEnabledLocalJVMProtocols.iterator();	
				while (iterator.hasNext()){
					so.addProtocol(iterator.next());
				}
			
				
				/* FOR ANY ACTUAL ENABLED PROTOCOLS MAKE A TEST BASED ON ECHO MESSAGING*/
				String testProtocol = defaultProtocol;
				String unexportedProtocol = defaultProtocol;
				StringBuffer stringBufferRequestEcho;
				String stringEcho;
				iterator = actualEnabledLocalJVMProtocols.iterator();
				Iterator<String> secondIterator;
				Iterator<String> thirdIterator;
				while (iterator.hasNext()) {
					testProtocol = iterator.next();
					thirdIterator = actualEnabledLocalJVMProtocols.iterator();
					secondIterator = actualEnabledLocalJVMProtocols.iterator();
					System.out.println("\n###### Iterative test: "+ testProtocol.toUpperCase() + " case");
					//unexport all protocol step by step, except the default one
					//and test communication as it happens in FallbackTest
					while (secondIterator.hasNext()) {
						unexportedProtocol = secondIterator.next();
						System.out.println("\nProtocol to unexport : " + unexportedProtocol.toUpperCase());
						stringBufferRequestEcho = new StringBuffer(
								"Connecting.... ");
						stringBufferRequestEcho.append(testProtocol.toUpperCase() + " case");
						String stringRequestEcho = new String(
								stringBufferRequestEcho.toString());
						if (unexportedProtocol.equals(defaultProtocol)) {
							// let (remote) active object echo some string
							stringEcho = soStub.doEchoRequest(stringRequestEcho);
							System.out.println(stringRequestEcho);
							assertTrue(stringEcho.equals(stringRequestEcho));
							if (stringEcho.equals(stringRequestEcho)) {
								System.out.println("Connected via default protocol - " + testProtocol.toUpperCase() + " case");
							}
						} else {
							
							// let (remote) active object echo some string
							stringEcho = soStub.doEchoRequest(stringRequestEcho);
							System.out.println(stringRequestEcho);
							assertTrue(stringEcho.equals(stringRequestEcho));
							if (stringEcho.equals(stringRequestEcho)) {
								System.out.println("Connected - " + testProtocol.toUpperCase() + " case");
							}
							//unexport protocol
							System.out.println("URL to unexport: "
									+ RemoteObjectHelper.generateUrl(
											unexportedProtocol, name));
							soStub.unexport(RemoteObjectHelper.generateUrl(
									unexportedProtocol, name));
							//perform a new echo request and test returned string
							stringEcho = soStub.doEchoRequest(stringRequestEcho);
							System.out.println(stringRequestEcho);
							// strings should be still equal since communication is local
							// Infact communication passes through loopback interface, does not across the TCP/IP stack!! 
							assertTrue(stringEcho.equals(stringRequestEcho));
							if (stringEcho.equals(stringRequestEcho)) {
								System.out.println("Connected - " + testProtocol.toUpperCase() + " case");
							}
						}

					}
					System.out.println("\n###### Unexported all Protocols on Server Object!!!!!!!!..."
							+ testProtocol.toUpperCase() + " case");
					//restore all protocols, previously unexported, on server object
					String restoredProtocol;
					while (thirdIterator.hasNext()) {
						restoredProtocol = thirdIterator.next();
						if (! restoredProtocol.equals(defaultProtocol))
							soStub.addProtocol(restoredProtocol);
							System.out.println(restoredProtocol + " " + defaultProtocol);
							System.out.println("Restoring protocol " + restoredProtocol.toUpperCase());
					}
				}
		    } 	


	public  ArrayList<String> getAllPossibleLocalFactoriesProtocols() {
		ArrayList<String> allPossibleLocalFactoriesProtocols = new ArrayList<String>();
		// discover all possible protocols
		Enumeration<String> eventualProtocols = RemoteObjectProtocolFactoryRegistry
				.keys();
		String currentProtocol = defaultProtocol;
		while (eventualProtocols.hasMoreElements()) {
			currentProtocol = eventualProtocols.nextElement();
			Class<?> rofClazz = RemoteObjectProtocolFactoryRegistry
					.get(currentProtocol);
			// Take into account just protocols with RemoteObjectFactory created
			if (rofClazz != null) {
				System.out.println("All Possible Local Factories Protocols: "
						+ currentProtocol);
				allPossibleLocalFactoriesProtocols.add(currentProtocol);
			}
		}
		return allPossibleLocalFactoriesProtocols;
	}

	public ArrayList<String> getActualEnabledLocalJvmProtocols() {
		
		if ( allPossibleLocalFactoriesProtocols == null ){
			allPossibleLocalFactoriesProtocols = getAllPossibleLocalFactoriesProtocols();
		}
		
		ArrayList<String> actualEnabledLocalJVMProtocols = new ArrayList<String>();
		
		String[] additionalProtocols = ProActiveConfiguration.getInstance()
				.getProperty("proactive.communication.additional_protocols")
				.split(",");
		actualEnabledLocalJVMProtocols.add(defaultProtocol);
		System.out.println("LocalJVMActualProtocol: " + defaultProtocol);
		for (int i = 0; i < additionalProtocols.length
				&& !actualEnabledLocalJVMProtocols
						.contains(additionalProtocols[i])
				&& allPossibleLocalFactoriesProtocols
						.contains(additionalProtocols[i]); i++) {
			actualEnabledLocalJVMProtocols.add(additionalProtocols[i]);
			System.out.println("LocalJVMActualProtocol: "
					+ additionalProtocols[i]);
		}

		return actualEnabledLocalJVMProtocols;
	}

	public  ArrayList<String> getEnabledserverobjectprotocols() {
		return enabledServerObjectProtocols;
	}

	public ArrayList<String> getActualEnabledServerObjectprotocols() throws UnknownProtocolException, ProActiveException, IOException {
		
		if ( allPossibleLocalFactoriesProtocols == null ){
			allPossibleLocalFactoriesProtocols = getAllPossibleLocalFactoriesProtocols();
		}
		
		if ( so == null || soStub == null ){
			inizializeTestComponents();
		}
		
		ArrayList<String> workableServerObjectProtocols = new ArrayList<String>();
		Iterator<String> iterator = allPossibleLocalFactoriesProtocols
				.iterator();
		String currentProtocol = defaultProtocol;
		boolean isPingable = false;
		while (iterator.hasNext()) {
			currentProtocol = iterator.next();
			// test if remote object is pingable by current protocol forcing
			try {
				// force the communication protocol
				PAActiveObject.forceProtocol(soStub, currentProtocol);
				isPingable = PAActiveObject.pingActiveObject(soStub);
				// unforce the communication protocol
				PAActiveObject.forceProtocol(soStub, null);
			} catch (NotYetExposedException e) {
				isPingable = false;
			} catch (UnknownProtocolException e) {
				isPingable = false;
			}
			// Take into account just protocols with RemoteObjectFactory created
			// and Remote Object pingable
			if (isPingable) {
				System.out.println("Workable protocols on server object: "
						+ currentProtocol);
				workableServerObjectProtocols.add(currentProtocol);
			}
		}
		
		return workableServerObjectProtocols;
	}


	private void inizializeTestComponents() throws UnknownProtocolException, ProActiveException, IOException{
	
		defaultProtocol = ProActiveConfiguration.getInstance()
				.getProperty("proactive.communication.protocol");
		name = "myActiveServerObject";
		uriString = String.valueOf(RemoteObjectHelper.generateUrl(defaultProtocol, name));
		
		so = (ServerObject) PAActiveObject.newActive(ServerObject.class,
				new Object[] { name });
		so.addProtocol(defaultProtocol);
		
		// look up for the (remote) active object and get its stub
		soStub = PAActiveObject.lookupActive(ServerObject.class, uriString);
	}
	
public ArrayList<String> getOrderedProtocols() {
		
		
		if ( allPossibleLocalFactoriesProtocols == null ){
			allPossibleLocalFactoriesProtocols = getAllPossibleLocalFactoriesProtocols();
		}
		
		ArrayList<String> orderedProtocols = new ArrayList<String>();
		
		if( ProActiveConfiguration.getInstance()
				.getProperty("proactive.communication.protocols.order") != null ) {
			
		
			String[] orderString = ProActiveConfiguration.getInstance()
					.getProperty("proactive.communication.protocols.order")
					.split(",");
			
			for (int i = 0; i < orderString.length
					&& allPossibleLocalFactoriesProtocols
							.contains(orderString[i]); i++) {
				orderedProtocols.add(orderString[i]);
				System.out.println("Protocols Order: " +
						i + " " + orderString[i]);
			}
		}
		
		return orderedProtocols;
	}

}


