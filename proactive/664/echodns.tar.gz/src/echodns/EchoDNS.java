package echodns;

import java.net.InetAddress;
import java.net.UnknownHostException;

import sun.net.spi.nameservice.NameService;
import sun.net.spi.nameservice.dns.DNSNameService;

public class EchoDNS implements NameService {
	
	private final DNSNameService dns_ns;
	
	public EchoDNS() throws Exception {
		System.err.println("Listening on DNS request muhahaw!");
		dns_ns = new DNSNameService();
	}

	public String getHostByAddr(byte[] arg0) throws UnknownHostException {
		System.err.println("\nReverse DNS request for \"" + printAddr(arg0) + "\" stacktrace is:" );
		new Throwable().printStackTrace();
		return dns_ns.getHostByAddr(arg0);
	}

	private String printAddr(byte[] data) {

		StringBuffer returnStringBuffer = new StringBuffer();

		if (data.length > 0)
		{
			int convert = data[0];
			if (convert < 0)
				convert += 256;
			returnStringBuffer.append(convert);

			for (int i = 1; i < data.length; i++)
			{
				convert = data[i];
				if (convert < 0)
					convert += 256;
				returnStringBuffer.append(".");
				returnStringBuffer.append(convert);
			}
		}

		return returnStringBuffer.toString();

	}

	public InetAddress[] lookupAllHostAddr(String arg0)
			throws UnknownHostException {
		System.err.println("DNS request for name \"" + arg0 + "\" stacktrace is:");
		new Throwable().printStackTrace();
		return dns_ns.lookupAllHostAddr(arg0);
	}

}
