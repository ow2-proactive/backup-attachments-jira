package echodns;

import sun.net.spi.nameservice.NameService;
import sun.net.spi.nameservice.NameServiceDescriptor;

public class EchoDnsDescriptor implements NameServiceDescriptor{

	@Override
	public String getProviderName() {
		// TODO Auto-generated method stub
		return "echodns";
	}
	
	@Override
	public NameService createNameService() throws Exception {
		return new EchoDNS();
	}
	
	@Override
	public String getType() {
		return "dns";
	}
	
}
