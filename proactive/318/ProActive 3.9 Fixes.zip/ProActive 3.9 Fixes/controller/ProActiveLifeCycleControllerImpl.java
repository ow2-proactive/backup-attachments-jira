package org.objectweb.proactive.core.component.controller;

// import gridcomp.controller.AutonomicController;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.objectweb.fractal.api.Component;
import org.objectweb.fractal.api.Interface;
import org.objectweb.fractal.api.NoSuchInterfaceException;
// import org.objectweb.fractal.api.control.ContentController;
import org.objectweb.fractal.api.control.IllegalLifeCycleException;
import org.objectweb.fractal.api.control.LifeCycleController;
// import org.objectweb.fractal.api.control.NameController;
import org.objectweb.fractal.api.factory.InstantiationException;
import org.objectweb.fractal.api.type.ComponentType;
import org.objectweb.fractal.api.type.InterfaceType;
import org.objectweb.fractal.api.type.TypeFactory;
import org.objectweb.fractal.util.Fractal;
import org.objectweb.proactive.core.ProActiveRuntimeException;
import org.objectweb.proactive.core.component.Constants;
import org.objectweb.proactive.core.component.Fractive;
import org.objectweb.proactive.core.component.group.ProxyForComponentInterfaceGroup;
import org.objectweb.proactive.core.component.type.ProActiveInterfaceType;
import org.objectweb.proactive.core.component.type.ProActiveTypeFactory;
import org.objectweb.proactive.core.component.type.ProActiveTypeFactoryImpl;
import org.objectweb.proactive.core.util.log.Loggers;
import org.objectweb.proactive.core.util.log.ProActiveLogger;

public class ProActiveLifeCycleControllerImpl extends AbstractProActiveController implements ProActiveLifeCycleController, Serializable 
{
	private static final long serialVersionUID = 1L;

	static final Logger logger = ProActiveLogger.getLogger(Loggers.COMPONENTS_CONTROLLERS);
    protected String fcState = LifeCycleController.STOPPED;
    
    public ProActiveLifeCycleControllerImpl(Component owner) 
    {
        super(owner);
    }

    @Override
    protected void setControllerItfType() 
    {
        try {
            setItfType(ProActiveTypeFactoryImpl.instance().createFcItfType(Constants.LIFECYCLE_CONTROLLER, ProActiveLifeCycleController.class.getName(), TypeFactory.SERVER, TypeFactory.MANDATORY, TypeFactory.SINGLE));
        } catch (InstantiationException e) {
            throw new ProActiveRuntimeException("cannot create controller " + this.getClass().getName());
        }
    }

    public String getFcState() 
    {
        return fcState;
    }

    public void startFc() 
    {
        try {
            checkMandatoryClientInterfaces();

            String hierarchical_type = Fractive.getComponentParametersController(getFcItfOwner()).getComponentParameters().getHierarchicalType();
            if (hierarchical_type.equals(Constants.COMPOSITE)) {
                Component[] inner_components = Fractal.getContentController(getFcItfOwner()).getFcSubComponents();
                if (inner_components != null) 
                    for (Component comp: inner_components)
                        ((LifeCycleController) comp.getFcInterface(Constants.LIFECYCLE_CONTROLLER)).startFc();
            }
            fcState = LifeCycleController.STARTED;
            if (logger.isDebugEnabled())
                logger.debug("started " + ((ComponentParametersController) getFcItfOwner().getFcInterface(Constants.COMPONENT_PARAMETERS_CONTROLLER)).getComponentParameters().getName());
        } catch (NoSuchInterfaceException nsie) {
            logger.error("interface not found : " + nsie.getMessage());
            nsie.printStackTrace();
        } catch (IllegalLifeCycleException ilce) {
            logger.error("illegal life cycle operation : " + ilce.getMessage());
            ilce.printStackTrace();
        }
    }

    public void stopFc()
    {
        try {
            // START PATCH
            // String hierarchical_type = ((ComponentParametersController) owner.getRepresentativeOnThis().getFcInterface(Constants.COMPONENT_PARAMETERS_CONTROLLER)).getComponentParameters().getHierarchicalType();
            String hierarchical_type = Fractive.getComponentParametersController(getFcItfOwner()).getComponentParameters().getHierarchicalType();
            // END PATCH
            if (hierarchical_type.equals(Constants.COMPOSITE)) {
                // START PATCH
                // Component[] inner_components = ((ContentController) owner.getRepresentativeOnThis().getFcInterface(Constants.CONTENT_CONTROLLER)).getFcSubComponents();
                Component[] inner_components = Fractal.getContentController(getFcItfOwner()).getFcSubComponents();
                // END PATCH
                if (inner_components != null)
                    for (Component comp: inner_components)
                        ((LifeCycleController) comp.getFcInterface(Constants.LIFECYCLE_CONTROLLER)).stopFc();
            }
            fcState = LifeCycleController.STOPPED;
            if (logger.isDebugEnabled()) 
                logger.debug("stopped " + ((ComponentParametersController) getFcItfOwner().getFcInterface(Constants.COMPONENT_PARAMETERS_CONTROLLER)).getComponentParameters().getName());
        } catch (NoSuchInterfaceException nsie) {
            logger.error("interface not found : " + nsie.getMessage());
        } catch (IllegalLifeCycleException ilce) {
            logger.error("illegal life cycle operation : " + ilce.getMessage());
        }
    }

    public String getFcState(short priority) 
    {
        return getFcState();
    }

    public void startFc(short priority) 
    {
        startFc();
    }

    public void stopFc(short priority) 
    {
        stopFc();
    }
    
    private void checkMandatoryClientInterfaces() throws IllegalLifeCycleException, NoSuchInterfaceException
    {
        //check that all mandatory client interfaces are bound
        InterfaceType[] itfTypes = ((ComponentType) getFcItfOwner().getFcType()).getFcInterfaceTypes();
        for (int i = 0; i < itfTypes.length; i++) {
            if (itfTypes[i].isFcClientItf() && !itfTypes[i].isFcOptionalItf()) {
                if (itfTypes[i].isFcCollectionItf()) {
                    // look for collection members
                    Object[] itfs = owner.getFcInterfaces();
                    for (int j = 0; j < itfs.length; j++) {
                        Interface itf = (Interface) itfs[j];
                        if (itf.getFcItfName().startsWith(itfTypes[i].getFcItfName())) {
                            if (itf.getFcItfName().equals(itfTypes[i].getFcItfName())) 
                                throw new IllegalLifeCycleException("invalid collection interface name at runtime (suffix required)");
                            if (Fractal.getBindingController(owner).lookupFc(itf.getFcItfName()) == null) 
                                throw new IllegalLifeCycleException("compulsory collection client interface " + itfTypes[i].getFcItfName() + " in component " + Fractal.getNameController(getFcItfOwner()).getFcName() + " is not bound. ");
                        }
                    }
                } else if (((ProActiveInterfaceType) itfTypes[i]).isFcMulticastItf() && !!itfTypes[i].isFcOptionalItf()) {
                    ProxyForComponentInterfaceGroup clientSideProxy = Fractive.getMulticastController(getFcItfOwner()).lookupFcMulticast(itfTypes[i].getFcItfName());
                    if (clientSideProxy.getDelegatee().isEmpty())
                        throw new IllegalLifeCycleException("compulsory multicast client interface " + itfTypes[i].getFcItfName() + " in component " + Fractal.getNameController(getFcItfOwner()).getFcName() + " is not bound. ");
                } else if ((((ProActiveInterfaceType) itfTypes[i]).getFcCardinality().equals(ProActiveTypeFactory.SINGLETON_CARDINALITY) || ((ProActiveInterfaceType) itfTypes[i]).getFcCardinality().equals(ProActiveTypeFactory.GATHER_CARDINALITY)) && (Fractal.getBindingController(getFcItfOwner()).lookupFc(itfTypes[i].getFcItfName()) == null)) 
                    throw new IllegalLifeCycleException("compulsory client interface " + itfTypes[i].getFcItfName() + " in component " + Fractal.getNameController(getFcItfOwner()).getFcName() + " is not bound. ");
                // TODO check compulsory client gathercast interface in composite
                // TODO add a test for client gathercast interface in composite
            }
        }
    }
    
    // START PATCH
    private void initializeControllers() throws NoSuchInterfaceException 
    {
    	String name = Fractal.getNameController(getFcItfOwner()).getFcName() ;
        Object[] itfs = owner.getRepresentativeOnThis().getFcInterfaces();
        for (int j = 0; j < itfs.length; j++) {
            Interface itf = (Interface) itfs[j];            
        	if (itf.getFcItfName().equals(gridcomp.Constants.REQUEST_PRIORITY_CONTROLLER)) {
        		PriorityController pc = (PriorityController) owner.getRepresentativeOnThis().getFcInterface(gridcomp.Constants.REQUEST_PRIORITY_CONTROLLER);
        		pc.init();
                if (logger.isDebugEnabled()) 
                    logger.debug("initialized priority controller in component " + name);
            // START NEW PATCH 
            /*
       		} else if (itf.getFcItfName().equals(gridcomp.Constants.AUTONOMIC_CONTROLLER)) {
        		AutonomicController ac = (AutonomicController) owner.getRepresentativeOnThis().getFcInterface(gridcomp.Constants.AUTONOMIC_CONTROLLER);
        		ac.init();
                if (logger.isDebugEnabled()) 
                    logger.debug("initialized autonomic controller in component " + name);
    		// END PATCH
            */
                            		
        	}
        }
    }
    // END NEW PATCH
}
