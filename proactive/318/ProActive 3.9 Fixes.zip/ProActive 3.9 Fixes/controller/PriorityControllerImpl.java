package org.objectweb.proactive.core.component.controller;

import java.util.Hashtable;
import java.util.Map;

import org.objectweb.fractal.api.Component;
import org.objectweb.fractal.api.factory.InstantiationException;
import org.objectweb.fractal.api.type.TypeFactory;
import org.objectweb.proactive.core.ProActiveRuntimeException;
import gridcomp.Constants;
import org.objectweb.proactive.core.component.Utils;
import org.objectweb.proactive.core.component.type.ProActiveTypeFactoryImpl;

public class PriorityControllerImpl extends AbstractProActiveController implements PriorityController
{
    private static final long serialVersionUID = 390L;
    private static final String ANY_PARAMETERS = "any-parameters";
    private Map<String, Object> nf2s;
    private Map<String, Object> nf3s;

    public PriorityControllerImpl(Component owner) {
        super(owner);
        nf2s = new Hashtable<String, Object>(2);
        nf2s.put("setPriorityNF2", ANY_PARAMETERS);
        nf3s = new Hashtable<String, Object>(3);
        nf3s.put("setPriorityNF3", ANY_PARAMETERS);
    }

    @Override
    protected void setControllerItfType() {
        try {
            setItfType(ProActiveTypeFactoryImpl.instance().createFcItfType(
                    Constants.REQUEST_PRIORITY_CONTROLLER, PriorityController.class.getName(),
                    TypeFactory.SERVER, TypeFactory.MANDATORY, TypeFactory.SINGLE));
        } catch (InstantiationException e) {
            throw new ProActiveRuntimeException("cannot create controller " + this.getClass().getName());
        }
    }

    ///////////////////////////////////////
    // PriorityController IMPLEMENTATION //
    ///////////////////////////////////////
    // TODO_C for a NF? priority check that the method is in a controller
    public void setPriority(String interfaceName, String methodName, RequestPriority priority) {
        switch (priority) {
            case NF1:
                nf2s.remove(methodName);
                nf3s.remove(methodName);
                break;
            case NF2:
                nf3s.remove(methodName);
                nf2s.put(methodName, ANY_PARAMETERS);
                break;
            case NF3:
                nf2s.remove(methodName);
                nf3s.put(methodName, ANY_PARAMETERS);
                break;
            default:
                break;
        }
    }

    // TODO_C for a NF? priority check that the method is in a controller
    public void setPriority(String interfaceName, String methodName, Class<?>[] parametersTypes,
            RequestPriority priority) {
        switch (priority) {
            case NF1:
                nf2s.remove(methodName);
                nf3s.remove(methodName);
                break;
            case NF2:
                nf3s.remove(methodName);
                nf2s.put(methodName, parametersTypes);
                break;
            case NF3:
                nf2s.remove(methodName);
                nf3s.put(methodName, parametersTypes);
                break;
            default:
                break;
        }
    }

    public RequestPriority getPriority(String interfaceName, String methodName, Class<?>[] parametersTypes) {
        if (nf2s.get(methodName) != null) {
            return RequestPriority.NF2;
        } else if (nf3s.get(methodName) != null) {
            return RequestPriority.NF3;
        } else if (Utils.isControllerInterfaceName(interfaceName)) {
            return RequestPriority.NF1;
        } else {
            return RequestPriority.F;
        }
    }

    // START PATCH
    public void init()
    {
        setPriority(Constants.REQUEST_QUEUE_CONTROLLER, "getSize", RequestPriority.NF2);
        setPriority(Constants.REQUEST_QUEUE_CONTROLLER, "popRequest", RequestPriority.NF2);
        setPriority(Constants.REQUEST_QUEUE_CONTROLLER, "pushRequest", RequestPriority.NF2);
        setPriority(Constants.REQUEST_QUEUE_CONTROLLER, "popRequests", RequestPriority.NF2);
        setPriority(Constants.REQUEST_QUEUE_CONTROLLER, "pushRequests", RequestPriority.NF2);
        
        setPriority(Constants.CONTENT_CONTROLLER, "getFcSubComponents", RequestPriority.NF2);
        setPriority(Constants.CONTENT_CONTROLLER, "addFcSubComponent", RequestPriority.NF2);
        setPriority(Constants.CONTENT_CONTROLLER, "removeFcSubComponent", RequestPriority.NF2);

        setPriority(Constants.LIFECYCLE_CONTROLLER, "startFc", RequestPriority.NF2);
        setPriority(Constants.LIFECYCLE_CONTROLLER, "stopFc", RequestPriority.NF2);
        setPriority(Constants.LIFECYCLE_CONTROLLER, "getFcState", RequestPriority.NF2);

        setPriority(Constants.BINDING_CONTROLLER, "lookupFc", RequestPriority.NF2);
        setPriority(Constants.BINDING_CONTROLLER, "bindFc", RequestPriority.NF2);
        setPriority(Constants.BINDING_CONTROLLER, "unbindFc", RequestPriority.NF2);
        setPriority(Constants.BINDING_CONTROLLER, "listFc", RequestPriority.NF2);

        setPriority(Constants.COMPONENT, "getFcInterface", RequestPriority.NF2);
        setPriority(Constants.COMPONENT, "getFcInterfaces", RequestPriority.NF2);

        setPriority(Constants.NAME_CONTROLLER, "getFcName", RequestPriority.NF2);
        setPriority(Constants.NAME_CONTROLLER, "setFcName", RequestPriority.NF2);

        setPriority(Constants.AUTONOMIC_CONTROLLER, "listAutonomicOperations", RequestPriority.NF2);
        setPriority(Constants.AUTONOMIC_CONTROLLER, "execOperation", RequestPriority.NF2);
        setPriority(Constants.AUTONOMIC_CONTROLLER, "getKnowledge", RequestPriority.NF2);

        setPriority(Constants.MONITOR_CONTROLLER, "getStatistics", RequestPriority.NF2);
        
    }
    // END PATCH
}