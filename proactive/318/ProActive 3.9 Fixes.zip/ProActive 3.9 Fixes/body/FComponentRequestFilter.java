package org.objectweb.proactive.core.component.body;

import org.objectweb.proactive.core.body.request.Request;
import org.objectweb.proactive.core.body.request.RequestFilter;
import org.objectweb.proactive.core.component.request.ComponentRequest;

public class FComponentRequestFilter implements RequestFilter 
{    
	private static final long serialVersionUID = 1L;

	public boolean acceptRequest(Request request) 
    {
        if (request instanceof ComponentRequest)
            return !((ComponentRequest) request).isControllerRequest();
        // standard requests cannot be component requests
        return false;
    }    
}
