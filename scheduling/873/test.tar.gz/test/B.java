package test;

import java.util.*;

public class B {
	private A a;
	
	public void setA(A a) {
		this.a = a;
	}
	
	public ArrayList foo() {
		Collection ans = a.foo2();
		System.out.println("Calling a.foo2() from b " + ans.size());
		return new ArrayList();
	}
}


