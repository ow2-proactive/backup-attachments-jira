package test;

import org.objectweb.proactive.api.PAActiveObject;

public class AutomaticContinuationTest {
	public static void main(String[] args) throws Exception {
		A a = PAActiveObject.newActive(A.class, null);
		B b = PAActiveObject.newActive(B.class, null);
		
		a.setB(b);
		b.setA(a);
		System.out.println("Calling a.foo()");
		System.out.println("Finished " + a.foo().size());
		System.exit(0);
	}
}
