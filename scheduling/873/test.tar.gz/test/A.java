package test;

import java.util.*;

public class A {

	private B b;

	public void setB(B b) {
		this.b = b;
	}
	
	public Collection foo() {
		return b.foo();
	}
	
	public Collection foo2() {
		return new ArrayList();
	}
}
