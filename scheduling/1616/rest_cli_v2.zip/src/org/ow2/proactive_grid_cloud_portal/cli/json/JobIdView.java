package org.ow2.proactive_grid_cloud_portal.cli.json;

public class JobIdView {

	private int id;
	private String readableName;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getReadableName() {
		return readableName;
	}

	public void setReadableName(String readableName) {
		this.readableName = readableName;
	}
}
