package org.ow2.proactive_grid_cloud_portal.cli.json;

public class UserView {

}
