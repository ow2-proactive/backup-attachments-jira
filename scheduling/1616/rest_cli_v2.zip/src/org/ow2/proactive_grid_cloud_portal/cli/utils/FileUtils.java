package org.ow2.proactive_grid_cloud_portal.cli.utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.security.MessageDigest;
import java.util.Scanner;

public class FileUtils {

	private static final int DEFAULT_BUFFER_SIZE = 1024 * 4;

	private FileUtils() {
	}

	public static byte[] byteArray(String pathname) throws IOException {
		InputStream input = new FileInputStream(pathname);
		OutputStream output = new ByteArrayOutputStream();
		byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
		int n = 0;
		while (-1 != (n = input.read(buffer))) {
			output.write(buffer, 0, n);
		}
		output.flush();
		output.close();
		return ((ByteArrayOutputStream) output).toByteArray();
	}

	public static void writeToFile(File file, String content)
			throws IOException {
		if (file.exists()) {
			file.delete();
		}
		Writer writer = new OutputStreamWriter(new FileOutputStream(file));
		try {
			writer.write(content);
		} finally {
			writer.close();
		}
	}

	public static String readFileContents(File file) throws IOException {
		return (new Scanner(file)).useDelimiter("\\A").next();
	}

	public static String getMD5Checksum(String pathname) throws Exception {
		byte[] b = createChecksum(pathname);
		String result = "";

		for (int i = 0; i < b.length; i++) {
			result += Integer.toString((b[i] & 0xff) + 0x100, 16).substring(1);
		}
		return result;
	}

	private static byte[] createChecksum(String pathname) throws Exception {
		FileInputStream fis = new FileInputStream(pathname);

		byte[] buffer = new byte[1024];
		MessageDigest complete = MessageDigest.getInstance("MD5");
		int numRead;
		do {
			numRead = fis.read(buffer);
			if (numRead > 0) {
				complete.update(buffer, 0, numRead);
			}
		} while (numRead != -1);

		fis.close();
		return complete.digest();
	}

}
