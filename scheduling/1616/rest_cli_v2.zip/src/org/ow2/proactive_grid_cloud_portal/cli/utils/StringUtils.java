package org.ow2.proactive_grid_cloud_portal.cli.utils;

import java.util.NoSuchElementException;
import java.util.Scanner;

import org.apache.http.HttpResponse;

public class StringUtils {
	
	public static String string(HttpResponse response) throws Exception {
		try {
			return (new Scanner(response.getEntity().getContent()))
					.useDelimiter("\\A").next();
		} catch (NoSuchElementException e) {
			return "";
		}
	}
	
	private StringUtils() {
	}

}
