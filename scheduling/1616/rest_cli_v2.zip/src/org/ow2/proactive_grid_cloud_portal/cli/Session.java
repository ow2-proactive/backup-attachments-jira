package org.ow2.proactive_grid_cloud_portal.cli;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.codehaus.jackson.map.ObjectMapper;
import org.ow2.proactive_grid_cloud_portal.cli.console.AbstractDevice;

public class Session {

	private static Session instance;

	private String user;
	private String password;
	private String sessionId;
	private AbstractDevice device;
	private boolean termiated = false;
	private String schedulerUrl;
	private ObjectMapper objectMapper;

	private boolean newSession = false;

	private Session() {
	}

	public static synchronized Session instance() {
		if (instance == null) {
			instance = new Session();
		}
		return instance;
	}

	public void setUser(String user) {
		this.user = user;
	}
	
	public String getUser() {
		return user;
	}

	public void setDevice(AbstractDevice device) {
		this.device = device;
	}

	public void setSchedulerUrl(String schedulerUrl) {
		this.schedulerUrl = schedulerUrl;
	}

	public void setObjectMapper(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	public boolean isNewSession() {
		return newSession;
	}

	public void setNewSession(boolean newSession) {
		this.newSession = newSession;
	}

	public synchronized void init(String schedulerUrl, AbstractDevice console) {
		this.schedulerUrl = schedulerUrl;
	}

	public AbstractDevice getDevice() {
		return device;
	}

	public boolean isTermiated() {
		return termiated;
	}

	public void setTermiated(boolean termiated) {
		this.termiated = termiated;
	}

	public HttpResponse executeClient(HttpUriRequest request) throws Exception {
		if (sessionId != null) {
			request.setHeader("sessionid", sessionId);
		}
		DefaultHttpClient client = new DefaultHttpClient();
		return client.execute(request);
	}

	public String getSchedulerUrl() {
		return schedulerUrl;
	}

	public ObjectMapper getObjectMapper() {
		return objectMapper;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getSessionId() {
		return sessionId;
	}

	public boolean logged() {
		return sessionId != null;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
