package org.ow2.proactive_grid_cloud_portal.cli.json;

public class TaskIdView {

	private String id;
	private String readableName;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getReadableName() {
		return readableName;
	}

	public void setReadableName(String readableName) {
		this.readableName = readableName;
	}
}
