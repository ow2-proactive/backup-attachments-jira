package org.ow2.proactive_grid_cloud_portal.cli.json;

public class ParallelEnvironmentView {

	private int nodesNumber;

	public int getNodesNumber() {
		return nodesNumber;
	}

	public void setNodesNumber(int nodesNumber) {
		this.nodesNumber = nodesNumber;
	}
}
