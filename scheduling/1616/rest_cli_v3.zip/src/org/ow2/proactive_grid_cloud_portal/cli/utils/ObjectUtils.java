package org.ow2.proactive_grid_cloud_portal.cli.utils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ObjectUtils {

	public static Object object(byte[] bytes) throws IOException,
			ClassNotFoundException {
		return new ObjectInputStream(new ByteArrayInputStream(bytes))
				.readObject();
	}

}
