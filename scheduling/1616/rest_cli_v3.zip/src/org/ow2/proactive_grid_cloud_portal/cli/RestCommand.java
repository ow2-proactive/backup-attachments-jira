package org.ow2.proactive_grid_cloud_portal.cli;

public enum RestCommand {

	URL("u", "url", "scheduler URL", "scheduler-url", 1, false),

	LOGIN("l", "login", "the username to join the Scheduler", "login-name", 1,
			false),

	PASSWORD("p", "password", "login password", "password", 1, false),

	LOGIN_WITH_CREDENTIALS("c", "--credentials",
			"The credentials file to be used to connect to the scheduler",
			"<pathname>", 1, false),

	SUBMIT_JOB_DESC("s", "submit", "submit job descriptor", "job-descriptor",
			1, false, "submit(job-descriptor)"),

	SUBMIT_JOB_ARCH("sa", "submitarchive", "submit job archive", "job-archive",
			1, false, "submit(job-archive)"),

	START_SCHEDULER("start", "startscheduler", "start scheduler", "start()"),

	STOP_SCHEDULER("stop", "stopscheduler", "stop scheduler", "stop()"),

	PAUSE_SCHEDULER("pause", "pausescheduler", "pause scheduler", "pause()"),

	RESUME_SCHEDULER("resume", "resumescheduler", "resume scheduler",
			"resume()"),

	FREEZE_SCHEDULER("freeze", "freezescheduler", "freeze scheduler",
			"freeze()"),

	KILL_SCHEDULER("kill", "killscheduler", "kill scheduler", "kill()"),

	GET_STATS("stats", "statistics", "get scheduler statistics", "stats()"),

	LIST_JOBS("lj", "listjobs", "list jobs", "listjobs()"),

	LINK_RM("lrm", "linkrm", "Reconnect a resource manager to the scheduler",
			"rm-url", 1, false, "linkrm(rm-url"),

	GET_JOB_OUTPUT("jo", "joboutput", "get job output", "job-id", 1, false,
			"joboutput(id)"),

	CHANGE_JOB_PRIORITY("jp", "jobpriority", "change job priority",
			"job-id priority", 2, false, "jobpriority(job-id,priority)"),

	GET_JOB_RESULT("jr", "jobresult", "get job result", "job-id", 1, false,
			"joboutput(job-id)"),

	GET_JOB_STATE("js", "jobstate", "get job state", "job-id", 1, false,
			"jobresult(job-id)"),

	PAUSE_JOB("pj", "pausejob", "pause job", "job-id", 1, false,
			"pausejob(job-id)"),

	RESUME_JOB("rj", "resumejob", "resume job", "job-id", 1, false,
			"resumejob(job-id)"),

	KILL_JOB("kj", "killjob", "kill job", "job-id", 1, false, "killjob(job-id)"),

	REMOVE_JOB("rj", "removejob", "remove job", "job-id", 1, false,
			"removejob(job-id)"),

	GET_TASK_OUTPUT("to", "taskoutput", "get task output", "job-id task-id", 2,
			false, "taskoutput(job-id,task-id)"),

	GET_TASK_RESULT("tr", "taskresult", "get task result", "job-id task-id", 2,
			false, "taskresult(job-id,task-id)"),

	PREEMPT_TASK("pt", "preempttask", "preempt task", "job-id task-id delay",
			3, false, "preempttask(job-id,task-id,delay)"),

	RESTART_TASK("rt", "restarttask", "restart task", "job-id task-id", 2,
			false, "restarttask(job-id,task-id)"),

	HELP("h", "help", "print the usage of REST CLI", "help()"),

	START_IMODE("i", "imode", "interactive mode", null);

	private String opt;
	private String longOpt;
	private String description;
	private String argsName;
	private int argsNum;
	private boolean argsRequired;
	private String jsOpt;

	RestCommand(String opt, String longOpt, String description) {
		this(opt, longOpt, description, null);
	}

	RestCommand(String opt, String longOpt, String description, String jsOpt) {
		this(opt, longOpt, description, null, 0, false, jsOpt);
	}

	RestCommand(String opt, String longOpt, String description,
			String argsName, int argsNum, boolean isArgsRequired) {
		this(opt, longOpt, description, argsName, argsNum, isArgsRequired, null);
	}

	RestCommand(String opt, String longOpt, String description,
			String argsName, int argsNum, boolean isArgsRequired, String jsOpt) {
		this.opt = opt;
		this.longOpt = longOpt;
		this.description = description;
		this.argsName = argsName;
		this.argsNum = argsNum;
		this.argsRequired = isArgsRequired;
		this.jsOpt = jsOpt;
	}

	public String getOpt() {
		return opt;
	}

	public void setOpt(String opt) {
		this.opt = opt;
	}

	public String getLongOpt() {
		return longOpt;
	}

	public void setLongOpt(String longOpt) {
		this.longOpt = longOpt;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getArgsName() {
		return argsName;
	}

	public void setArgsName(String argsName) {
		this.argsName = argsName;
	}

	public int getArgsNum() {
		return argsNum;
	}

	public void setArgsNum(int argsNum) {
		this.argsNum = argsNum;
	}

	public boolean isArgsRequired() {
		return argsRequired;
	}

	public void setArgsRequired(boolean argsRequired) {
		this.argsRequired = argsRequired;
	}

	public String getJsOpt() {
		return jsOpt;
	}

	public void setJsOpt(String jsOpt) {
		this.jsOpt = jsOpt;
	}
}
