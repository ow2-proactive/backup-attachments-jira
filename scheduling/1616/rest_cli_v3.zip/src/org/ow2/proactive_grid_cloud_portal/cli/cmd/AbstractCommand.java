/*
 * ################################################################
 *
 * ProActive Parallel Suite(TM): The Java(TM) library for
 *    Parallel, Distributed, Multi-Core Computing for
 *    Enterprise Grids & Clouds
 *
 * Copyright (C) 1997-2012 INRIA/University of
 *                 Nice-Sophia Antipolis/ActiveEon
 * Contact: proactive@ow2.org or contact@activeeon.com
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Affero General Public License
 * as published by the Free Software Foundation; version 3 of
 * the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * If needed, contact us to obtain a release under GPL Version 2 or 3
 * or a different license than the AGPL.
 *
 *  Initial developer(s):               The ProActive Team
 *                        http://proactive.inria.fr/team_members.htm
 *  Contributor(s):
 *
 * ################################################################
 * $$PROACTIVE_INITIAL_DEV$$
 */

package org.ow2.proactive_grid_cloud_portal.cli.cmd;

import static org.ow2.proactive_grid_cloud_portal.cli.ResponseStatus.FORBIDDEN;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import org.codehaus.jackson.type.TypeReference;
import org.ow2.proactive_grid_cloud_portal.cli.ResponseStatus;
import org.ow2.proactive_grid_cloud_portal.cli.RestCliException;
import org.ow2.proactive_grid_cloud_portal.cli.Session;
import org.ow2.proactive_grid_cloud_portal.cli.json.ErrorView;
import org.ow2.proactive_grid_cloud_portal.cli.utils.ArrayFormatter;
import org.ow2.proactive_grid_cloud_portal.cli.utils.FileUtils;
import org.ow2.proactive_grid_cloud_portal.cli.utils.ObjectUtils;
import org.ow2.proactive_grid_cloud_portal.cli.utils.StringUtils;
import org.ow2.proactive_grid_cloud_portal.cli.utils.Tools;

public abstract class AbstractCommand implements Command {

	public AbstractCommand() {
	}

	protected static String string(HttpResponse response) throws Exception {
		return StringUtils.string(response);
	}

	protected static String string(ArrayFormatter oaf) {
		return Tools.getStringAsArray(oaf);
	}

	protected static String formattedDate(long time) {
		return Tools.getFormattedDate(time);
	}

	protected static String formattedElapsedTime(long time) {
		return Tools.getElapsedTime(time);
	}

	protected static String formattedDuration(long start, long end) {
		return Tools.getFormattedDuration(start, end);
	}

	protected static Object object(byte[] bytes) throws Exception {
		if (bytes == null) {
			return "[NULL]";
		}
		return ObjectUtils.object(bytes);
	}

	protected static int statusCode(ResponseStatus status) {
		return status.statusCode();
	}

	protected static int statusCode(HttpResponse response) {
		return response.getStatusLine().getStatusCode();
	}

	public static String getMD5Checksum(String pathname) throws Exception {
		return FileUtils.getMD5Checksum(pathname);
	}

	protected static void writeToFile(File file, String content)
			throws IOException {
		FileUtils.writeToFile(file, content);
	}

	protected static byte[] byteArray(String pathname) throws IOException {
		return FileUtils.byteArray(pathname);
	}

	protected static String readFileContents(File file) throws IOException {
		return FileUtils.readFileContents(file);
	}

	protected Session session() {
		return Session.instance();
	}

	protected <T> T readValue(HttpResponse response, Class<T> valueType)
			throws Exception {
		return session().getObjectMapper().readValue(
				response.getEntity().getContent(), valueType);
	}

	protected <T> T readValue(HttpResponse response, TypeReference<T> valueType)
			throws Exception {
		return session().getObjectMapper().readValue(
				response.getEntity().getContent(), valueType);
	}

	protected String resourceUrl(String resource) {
		return session().getSchedulerUrl() + "/scheduler/" + resource;
	}

	protected void writeLine(String format, Object... args) throws Exception {
		session().getDevice().writeLine(format, args);
	}

	protected String readLine(String format, Object... args) throws IOException {
		return session().getDevice().readLine(format, args);
	}

	protected char[] readPassword(String format, Object... args)
			throws IOException {
		return session().getDevice().readPassword(format, args);
	}

	protected HttpResponse execute(HttpUriRequest request) throws Exception {
		return session().executeClient(request);
	}

	protected void handleError(String errorMsg, HttpResponse response)
			throws Exception {
		writeLine(errorMsg);
		String responseContent = string(response);
		ErrorView errorView = null;
		try {
			errorView = session().getObjectMapper().readValue(
					responseContent.getBytes(), ErrorView.class);
		} catch (Throwable error) {
			// ignore
		}
		if (errorView != null) {
			writeError(errorView);
		} else {
			writeError(responseContent);
		}
	}

	private void writeError(String responseContent) throws Exception {
		String errorMessage = null, errorCode = null;
		BufferedReader reader = new BufferedReader(new StringReader(
				responseContent));

		String line = reader.readLine();
		while ((line = reader.readLine()) != null) {
			if (line.startsWith("errorMessage:")) {
				errorMessage = line.substring(line.indexOf(':')).trim();
				break;
			}
		}

		while ((line = reader.readLine()) != null) {
			if (line.startsWith("httpErrorCode:")) {
				errorCode = line.substring(line.indexOf(':')).trim();
				break;
			}
		}

		if (errorCode != null) {
			writeLine("HTTP Error Code: " + errorCode);
		}

		if (errorMessage != null) {
			writeLine("Error Message: " + errorMessage);
		}

		while ((line = reader.readLine()) != null) {
			if (line.startsWith("stackTrace:")) {
				String printStacktTrace = session().getDevice().readLine(
						"Print Stack Trace [y/n]:");
				if ("y".equalsIgnoreCase(printStacktTrace)) {
					while ((line = reader.readLine()) != null) {
						writeLine(line);
					}
				}
				break;
			}
		}
	}

	private void writeError(ErrorView error) throws Exception {
		if (statusCode(FORBIDDEN) == error.getHttpErrorCode()) {
			// this exception would be handled at an upper level ..
			throw new RestCliException(error.getHttpErrorCode(),
					error.getErrorMessage());
		}
		writeLine("HTTP Error Code: " + error.getHttpErrorCode());
		writeLine("Error Message: " + error.getErrorMessage());

		String choice = readLine("Print Stack Trace [y/n]:");
		if ("y".equalsIgnoreCase(choice)) {
			writeLine(error.getStackTrace());
		}
	}

}
